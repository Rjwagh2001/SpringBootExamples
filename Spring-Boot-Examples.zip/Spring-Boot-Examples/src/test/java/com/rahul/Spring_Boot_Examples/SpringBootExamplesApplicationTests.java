package com.rahul.Spring_Boot_Examples;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootExamplesApplicationTests {

	@Test
	void contextLoads() {
	}

}
