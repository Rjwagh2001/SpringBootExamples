package com.rahul.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestApIExamplesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApIExamplesApplication.class, args);
	}

}
